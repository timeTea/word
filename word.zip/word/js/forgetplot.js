var forget = document.getElementById('fogetChart').getContext('2d');
var forgetChart = new Chart(forget, {
    type: 'line',
    data: {
        labels: ["今天","明天","后天","3天后","4天后","5天后","6天后","7天后","8天后","9天后"],
        datasets: [{
            label: '你的学习遗忘曲线',
            data: [100,98,97,92,91,80,78,70,58,45],
            backgroundColor: [
                'rgba(255, 99, 132, 0)'
            ],
            borderColor: [
                'rgba(255,99,132,1)'
            ],
            borderWidth: 1
        },{
            label: '艾宾浩斯遗忘曲线 The Ebbinghaus Forgetting Curve',
            data: [100,33.7,27.8,26.8,26.1,25.7,25.4,25.2,25.1,25],
            backgroundColor: [
                'rgba(155, 199, 32, 0)'
            ],
            borderColor: [
                'rgba(255,99,132,1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});