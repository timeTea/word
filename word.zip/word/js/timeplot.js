var time = document.getElementById('timeChart').getContext('2d');
var timeChart = new Chart(time, {
    type: 'line',
    data: {
        labels: ["9天前","8天前","7天前","6天前","5天前", "4天前", "3天前", "前天", "昨天", "今天"],
        datasets: [{
            label: '记忆持久度>10天的词汇量',
            data: [908, 908, 908,908,908,908,908,908,908,908,],
            borderColor: [
                'rgba(120,219,32,1)'
            ],
            backgroundColor:[
                'rgba(120,219,32,0)'
            ],
            borderWidth: 1
        },{
            label: '已加入记忆规划的全部单词',
            data: [1309, 1309,1309,1309,1309,1309,1309,1309,1309,1309],
            borderColor: [
                'rgba(70,89,232,1)'
            ],
            backgroundColor:[
                'rgba(120,219,32,0)'
            ],
            borderWidth: 1
        },{
            label:'记忆持久度>30天的词汇量',
            data:[679,679,679,679,679,679,679,679,679,679],
            borderColor:[
                'rgba(200,120,70,1)'
            ],
            backgroundColor:[
                'rgba(200,120,70,0)'
            ],
            borderWidth:1
        },{
            label:'记忆持久度>60天的词汇量',
            data:[295,295,295,295,295,295,295,295,295,295],
            borderColor:[
                'rgba(90,200,120,1)'
            ],
            backgroundColor:[
                'rgba(90,200,120,0)'
            ],
            borderWidth:1
        },{
            label:"记忆持久度>90天的词汇量",
            data:[0,0,0,0,0,0,0,0,0,0],
            borderColor:[
                'rgba(90,120,190,1)'
            ],
            backgroundColor:[
                'rgba(90,120,190,0)'
            ]
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});