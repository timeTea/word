app.service("word",function($q,$http){
    var def = $q.defer();
    var promise = def.promise;
    $http({
        method:'GET',
        url:'data/word.json'
    },{
        method:'GET',
        url:'data/word.json'
    })
    .then(function(res){
        def.resolve({
            data:res.data
        });
    },function(err){
        console.log("error");
    })
    return promise;
})
// app.service('articles',function($q,$http){
//     var def = $q.defer();
//     var promise = def.promise;
//     $http({
//         method:'GET',
//         url:'data/article.json'
//     },{
//         method:'GET',
//         url:'data/article.json'
//     })
//     .then(function(res){
//         def.resolve({
//             data:res.data
//         });
//     },function(err){
//         console.log("error");
//     })
//     return promise;
// })
app.service('art',function($q,$http){
    var def = $q.defer();
    var promise = def.promise;
    $http({
        method:'GET',
        url:'http://120.77.205.28/article.php'
    },{
        method:'GET',
        url:'http://120.77.205.28/article.php'
    })
    .then(function(res){
        def.resolve({
            data:res.data
        });
    },function(err){
        console.log("error");
    })
    return  promise;
})
app.service('content',function($q,$http){
    var def = $q.defer();
    var promise = def.promise;
    $http({
        method:'GET',
        url:'http://120.77.205.28/content.php'
    },{
        method:'GET',
        url:'http://120.77.205.28/content.php'
    })
    .then(function(res){
        def.resolve({
            data:res.data
        });
    },function(err){
        console.log("error");
    })
    return  promise;
})
app.service('words',function($q,$http){
    var def = $q.defer();
    var promise = def.promise;
    $http({
        method:'GET',
        url:'http://120.77.205.28/word.php'
    },{
        method:'GET',
        url:'http://120.77.205.28/word.php'
    })
    .then(function(res){
        def.resolve({
            data:res.data
        });
    },function(err){
        console.log("error");
    })
    return promise;
})