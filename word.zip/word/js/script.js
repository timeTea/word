var login = 0;

app.config(function($routeProvider,$locationProvider){
    $locationProvider.hashPrefix('');
    $routeProvider.when('/word/:id',{
        templateUrl:"word.html",
        controller:"wordCtrl"
    })
    .when('/meaning/:id',{
        templateUrl:"meaning.html",
        controller:"meaningCtrl"
    })
    .when('/registe',{
        templateUrl:"registe.html",
        controller:"registeCtrl"
    })
    .when('/button',{
        templateUrl:"button.html",
        controller:"buttonCtrl"
    })
    .when('/forget',{
        templateUrl:"forget.html",
        controller:"forgetCtrl"
    })
    .when('/setting/:name',{
        templateUrl:"setting.html",
        controller:"setCtrl"
    })
    .when('/error',{
        templateUrl:"error.html",
        controller:"errorCtrl"
    })
    .when('/reading',{
        templateUrl:"reading.html",
        controller:"readingCtrl"
    })
    .when('/article/:id',{
        templateUrl:"article.html",
        controller:"articleCtrl"
    })
    .when('/load',{
        templateUrl:"load.html",
        controller:"loadCtrl"
    })
    .when('/fail',{
        templateUrl:"fail.html",
        controller:"failCtr"
    })
    .when('/err',{
        templateUrl:"err.html",
        controller:"errCtrl"
    })
    .when('/none',{
        templateUrl:"none.html",
        controller:"noneCtrl"
    })
    .otherwise({
        redirectTo:"/word/0"
    })
});
app.controller("registeCtrl",function($q,$http,$scope,$location){
        $scope.sure = function(){
            var def = $q.defer();
            var promise = def.promise;
            var name=$scope.name;
            var password=$scope.password;

            $http({
                method:"GET",
                url:"http://120.77.205.28/registe.php?name="+name+"&password="+password
            })
            .then(function(res){
                def.resolve({
                    data:res.data
                });
            },function(err){
                console.log("error");
            })

            promise.then(function(res){
                console.log(res.data);
                if(res.data==1)
                    $location.path('/load');
                else{
                    $location.path('/err');
                }
            })

    }
})

app.controller("errCtrl",function($scope,$location){
    $scope.back = function(){
        $location.path('/load');
    }
})

app.controller("errorCtrl",function($scope,$location){
    $scope.back = function(){
        $location.path('/load');
    }
})

app.controller("forgetCtrl",function($scope,$http,$q,$location){
    $scope.sure = function(){
        var def = $q.defer();
        var promise = def.promise;
        var name=$scope.name;
        var password=$scope.password;

        $http({
            method:"GET",
            url:"http://120.77.205.28/forget.php?name="+name+"&password="+password
        })
        .then(function(res){
            def.resolve({
                data:res.data
            });
        },function(err){
            console.log("error");
        })

        promise.then(function(res){
            if(res.data==1)
                $location.path('/load');
            else{
                $location.path('/error');
            }
        })

    }
})

app.controller('noneCtrl',function($scope,$location){
    $scope.back=function(){
        $location.path('/load');
    }
})

app.controller("meaningCtrl",function($scope,word,$routeParams,$location){    
    $scope.count=function(){
        if(login==0){
            $location.path("/none");
        }
        else{
            console.log("forget");
            window.location.href="data_foget.html";
        }
    }
    
    word.then(function(res){
        $scope.item = res.data[$routeParams.id];
        console.log(res);
    },function(err){
        console.log("error");
    })
});
app.controller("setCtrl",function($location,$scope,$routeParams){    
    $scope.count=function(){
        if(login==0){
            $location.path("/none");
        }
        else{
            console.log("forget");
            window.location.href="data_foget.html";
        }
    }
    $scope.name = $routeParams.name;
    if(login==0){
        console.log("ok");
        $location.path("/load");
    }
    $scope.cancel=function(){
        $location.path("/load");
    }
});
app.controller("loadCtrl",function($scope,$q,$http,$location){
    $scope.registe = function(){
        $location.path('/registe');
    }
    $scope.forget=function(){
        $location.path("/forget");
    }
    $scope.login=function(){
        var name=$scope.name;
        var password=$scope.password;
        var def = $q.defer();
        var promise = def.promise;

        $http({
            method:'GET',
            url:"http://120.77.205.28/today.php?name="+name+"&password="+password
        })
        .then(function(res){
            def.resolve({
                data:res.data
            });
        },function(err){
            console.log("error");
        });
        
        promise.then(function(data) {
            var result = data.data;
            if(result==0) {
                $location.path('/fail');
            } else {
                login = 1;
                console.log(result.name);
                var id='/setting/'+result.name;
                $location.path(id);
            }
        }, function(error) {
            console.log(error);
        });
    }
})
app.controller("wordCtrl",function($scope,words,$routeParams,$location){    
    $scope.count=function(){
        if(login==0){
            $location.path("/none");
        }
        else{
            console.log("forget");
            window.location.href="data_foget.html";
        }
    }
    words.then(function(res){
        if($routeParams.id>5)
            $scope.item  = res.data[0];
        else{
            $scope.item = res.data[$routeParams.id];
        }
    },function(err){
        console.log("error");
    })
});
app.controller("readingCtrl",function($scope,art,$location){    
    $scope.count=function(){
        if(login==0){
            $location.path("/none");
        }
        else{
            console.log("forget");
            window.location.href="data_foget.html";
        }
    }
    art.then(function(res){
        $scope.article = res.data;
    },function(err){
        console.log("error");
    })
    $scope.carousel = function(){
        $(".carousel").carousel({interval:2000});
    }
    $scope.prev = function(){
        $(".carousel").carousel("prev")
    }
    $scope.next = function(){
        $(".carousel").carousel("next")
    }
})
/* app.controller("articleCtrl",function($scope,articles,$routeParams,content){
    articles.then(function(res){
        $scope.item = res.data[$routeParams.id];
    },function(err){
        console.log("error");
    });
}) */
app.controller("articleCtrl",function($scope,$routeParams,$location,content){
    $scope.count=function(){
        if(login==0){
            $location.path("/none");
        }
        else{
            console.log("forget");
            window.location.href="data_foget.html";
        }
    }
    content.then(function(res){
        var ex = {id:undefined,title:undefined,image:undefined,content:[]};
        var ans = [{id:undefined,title:undefined,image:undefined,content:[]}];
        var b=0;
        ans[b].id=res.data[b].id;
        ans[b].title=res.data[b].title;
        ans[b].image=res.data[b].image;
        ans[b].content.push(res.data[b].content);
        for(var a=1;a<res.data.length;a++){
            if(ans[b].id==res.data[a].id){
                ans[b].content.push(res.data[a].content);
            }else{
                b++;
                ans.push(ex);
                ans[b].id=res.data[a].id;
                ans[b].title=res.data[a].title;
                ans[b].image=res.data[a].image;
                ans[b].content.push(res.data[a].content);
            }
        }
        console.log(ans);
        $scope.item = ans[$routeParams.id];
    },function(err){
        console.log("error");
    });
})