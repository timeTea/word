<?php

$conn = mysqli_connect("120.77.205.28","word","1234567890","word");

$sql = "set names utf8";

mysqli_query($conn,$sql);

$sql = "select * from article";

$result = mysqli_query($conn,$sql);

$json = [];

while ($row = mysqli_fetch_assoc($result)) {
    # code...
    $json[] = $row;
}

echo json_encode($json);

#phonegap
#xampp
#cordovca