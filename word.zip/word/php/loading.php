
<?php
    if($_POST["name"]=="qiujinhuai@163.com"&&$_POST["password"]=="123456")
        header("Location: ../index.html#/word/0");
    else echo "error!";
    echo "<br>";
    echo "<a href='../index.html'>back</a>";
?>