<?php
	header("Access-Control-Allow-Origin:*");
	$username = $_GET["name"];
	$password = $_GET["password"];
	$conn = mysqli_connect("localhost","root","","word");
	$sql = "select id from user where name= '$username'";
	$row=10;

	if($result = mysqli_query($conn,$sql)){
        $row = mysqli_num_rows($result);
    };


	if($row==1){
        $id = $result;
        $sql = "delete from user where name= '$username'";
        if($result = mysqli_query($conn,$sql)){
            // INSERT INTO `user` (`id`, `name`, `password`) VALUES ('1', 'jinhuai', '123');
            $sql = "insert into user (id,name,password) values ('1','$username','$password');";
                if($result = mysqli_query($conn,$sql)){
                    echo 1;
                }
        }
	}else{
		echo 0;
	}

?>