<?php
	header("Access-Control-Allow-Origin:*");
	$username = $_GET["name"];
	$password = $_GET["password"];
    $conn = mysqli_connect("localhost","root","","word");
    $sql = "select * from user where name='$username'";

	$row=10;
	if($result = mysqli_query($conn,$sql)){
        $row = mysqli_num_rows($result);
    };

	if($row==0){
        $sql = "insert into user (id,name,password) values ('1','$username','$password');";
        if($result = mysqli_query($conn,$sql)){
            echo 1;
        }
	}else{
		echo 0;
	}

?>