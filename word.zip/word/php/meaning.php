<?php

$conn = mysqli_connect("localhost","root","","word");

$sql = "set names utf8";

mysqli_query($conn,$sql);

$sql = "select example.id,word,phonetic,others,means,examples from word,others,means,example where word.id=others.id=means.id=example.id";

$result = mysqli_query($conn,$sql);

$json = [];

while ($row = mysqli_fetch_assoc($result)) {
    # code...
    $json[] = $row;
}

echo json_encode($json);

#phonegap
#xampp
#cordovca