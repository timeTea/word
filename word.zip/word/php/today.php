<?php
	header("Access-Control-Allow-Origin:*");
	$username = $_GET["name"];
	$password = $_GET["password"];
	$conn = mysqli_connect("localhost","root","","word");
	$sql = "select * from user where name= '$username' and password= '$password'";
	$row=10;

	if($result = mysqli_query($conn,$sql)){
		$row = mysqli_num_rows($result);
		$json = mysqli_fetch_assoc($result);
	};

	if($row==1){
		echo json_encode($json);
	}else{
		echo 0;
	}

?>