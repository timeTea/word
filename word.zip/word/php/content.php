<?php

$conn = mysqli_connect("localhost","root","","word");

$sql = "set names utf8";

mysqli_query($conn,$sql);

$sql = "select content.id,title,image,content from content,article where content.id=article.id";

$result = mysqli_query($conn,$sql);

$json = [];

while ($row = mysqli_fetch_assoc($result)) {
    # code...
    $json[] = $row;
}

echo json_encode($json);

#phonegap
#xampp
#cordovca